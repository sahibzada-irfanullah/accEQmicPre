#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn import ensemble
from sklearn import neural_network
from sklearn import tree
from sklearn import metrics
from sklearn import naive_bayes
from sklearn.feature_extraction.text import CountVectorizer
fname = 'dataset/amazon_cells_labelled.csv'
df = pd.read_csv(fname)
vect = CountVectorizer(stop_words='english')
def strat_KFold_CV(X, y, clf, n_splits=5, shuffle=True):
    stratified_k_fold = StratifiedKFold(n_splits=n_splits, shuffle=shuffle)
    X_train_dtm = X
    X_train_dtm = X_train_dtm.toarray()
    y_pred= y.copy()
    for train_index, test_index in stratified_k_fold.split(X_train_dtm, y):
        X_train, X_test = X_train_dtm[train_index], X_train_dtm[test_index]
        y_train = y[train_index]
        clf.fit(X_train, y_train)
        y_pred_tem = clf.predict(X_test)
        y_pred[test_index] = y_pred_tem 
    return y_pred

X_dtm = vect.fit_transform(df['text']) 
y = df["class"]

print(50*"+")
y_pred = strat_KFold_CV(X_dtm, y, naive_bayes.MultinomialNB())
print('Multinomial Naive Bayes:Accuracy: {:.2f}'.format(metrics.accuracy_score(y, y_pred)*100))
print('Multinomial Naive Bayes:Micro Precision: {:.2f}'.format(metrics.precision_score(y, y_pred, average = 'micro')*100))
print(50*"+")

y_pred = strat_KFold_CV(X_dtm, y, neural_network.MLPClassifier())
print('MLP:Accuracy: {:.2f}'.format(metrics.accuracy_score(y, y_pred)*100))
print('MLP:Micro Precision: {:.2f}'.format(metrics.precision_score(y, y_pred, average = 'micro')*100))
print(50*"+")

y_pred = strat_KFold_CV(X_dtm, y, tree.DecisionTreeClassifier())
print('Decision Tree:Accuracy: {:.2f}'.format(metrics.accuracy_score(y, y_pred)*100))
print('Decision Tree:Micro Precision: {:.2f}'.format(metrics.precision_score(y, y_pred, average = 'micro')*100))
print(50*"+")

y_pred = strat_KFold_CV(X_dtm, y, ensemble.RandomForestClassifier())
print('Random Forest Classifier:Accuracy: {:.2f}'.format(metrics.accuracy_score(y, y_pred)*100))
print('Random Forest Classifier:Micro Precision: {:.2f}'.format(metrics.precision_score(y, y_pred, average = 'micro')*100))


# In[ ]:




